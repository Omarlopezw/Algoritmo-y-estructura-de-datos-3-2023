Se agrega la recarga de clientes al iniciar
Se agrega ocultamiento de información. Se usan properties en la clase POJO Customer.
Se agrega la opción de iniciar con código en 100
